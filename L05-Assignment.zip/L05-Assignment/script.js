async function fetchCat() {

    let myCat = await fetch('https://catfact.ninja/fact?max_length=140')
        .then(res => res.json());

        var catFact = myCat.fact;
        var catFactLength = myCat.length;

        console.log(catFact);
        console.log(catFactLength);

        const container = document.getElementById('factWrapper');

        const catFactP = document.createElement('p');
        const h3 = document.createElement("h3");

        h3.textContent = 'Random Cat Facts For Cat People';
        catFactP.textContent = ("Cats Are Stupid But Here Is A Fact: " + catFact);
        
        container.appendChild(h3);
        container.appendChild(catFactP);

    }

fetchCat();